export default {
  navigationBarTitleText: '购物车',
  usingComponents:{}
}
