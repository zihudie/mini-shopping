export default {
  navigationBarTitleText: '商品管理',
  usingComponents: {},
}
