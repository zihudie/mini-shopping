export default {
  navigationBarTitleText: '商品配置',
  usingComponents: {},
}
