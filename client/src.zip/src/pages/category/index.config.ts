export default {
  navigationBarTitleText: '商品分类',
  usingComponents: {},
}
